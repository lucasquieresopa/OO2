package practica.OO2.ejercicio13;

public class Usuario {

	private String mail, contrasena;

	public Usuario(String mail, String contrasena) {
		this.mail = mail;
		this.contrasena = contrasena;
	}

	
}
