package practica.OO2.ejercicio11;

public class Ringer {

	public void ring() {
		
	}
}
