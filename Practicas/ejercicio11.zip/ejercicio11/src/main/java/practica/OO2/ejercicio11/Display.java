package practica.OO2.ejercicio11;

public class Display {

	public String showBanner(String img) {
		
		return null;
	}
}
