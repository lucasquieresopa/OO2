package practica.OO2.ejercicio11;

public class Connection4G{

	private String symb;

	public String transmit(String data, long crc) {

		return null;
	}
	
	public String symb() {
		return this.symb;
	}


}
