package practica.OO2.ejercicio11;

public interface Connection {

	public abstract String sendData(String data, long crc);
	public abstract String pict();
}
