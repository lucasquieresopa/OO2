package practica.OO2.ejercicio11;

public abstract class CRC_Calculator {

	protected abstract long crcFor(String data);

}
