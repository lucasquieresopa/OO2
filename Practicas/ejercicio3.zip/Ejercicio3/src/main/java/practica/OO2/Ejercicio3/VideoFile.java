package practica.OO2.Ejercicio3;

public class VideoFile extends Media{

	public void play() {
		
	}
}
