package practica.OO2.Ejercicio3;

public class Audio extends Media{

	public void play() {
		
	}
}
