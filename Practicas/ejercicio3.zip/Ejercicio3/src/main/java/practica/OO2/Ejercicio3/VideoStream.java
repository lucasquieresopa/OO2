package practica.OO2.Ejercicio3;

public class VideoStream {

	public void reproduce() {
		
	}
}
