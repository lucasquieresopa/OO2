package practica.OO2.Ejercicio3;

public class MediaPlayer {

	private Media archivosAudioYVideo;
}
