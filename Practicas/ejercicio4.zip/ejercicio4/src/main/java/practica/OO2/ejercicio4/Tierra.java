package practica.OO2.ejercicio4;

public class Tierra extends Simple{

	public double proporcionDeAgua() {
		return 0.0;
	}
}
