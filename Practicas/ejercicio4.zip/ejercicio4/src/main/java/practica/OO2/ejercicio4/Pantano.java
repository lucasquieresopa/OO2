package practica.OO2.ejercicio4;

public class Pantano extends Simple{

	public double proporcionDeAgua() {
		return 0.7;
	}
}
