package practica.OO2.ejercicio4;

public abstract class Topografia {
	
	public abstract double proporcionDeAgua();

	protected abstract Object disposicion();

}
