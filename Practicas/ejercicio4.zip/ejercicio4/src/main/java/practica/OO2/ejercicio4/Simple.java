package practica.OO2.ejercicio4;

public abstract class Simple extends Topografia{

	public Object disposicion() {
		return true;
	}
}
