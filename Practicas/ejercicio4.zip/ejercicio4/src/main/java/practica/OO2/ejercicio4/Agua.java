package practica.OO2.ejercicio4;

public class Agua extends Simple{

	public double proporcionDeAgua() {
		return 1.0;
	}
}
