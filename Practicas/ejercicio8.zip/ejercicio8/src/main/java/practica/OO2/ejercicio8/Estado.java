package practica.OO2.ejercicio8;


public abstract class Estado {

	public abstract void inscribir(Excursion excursion, Usuario usuario);
	public abstract String obtenerInformacion(Excursion excursion);
}
