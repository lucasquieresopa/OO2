package ejer6;

public class Ancestro {

	private boolean hayCamino = false;
	private boolean encontre = false;
	
	public boolean isHayCamino() {
		return hayCamino;
	}
	public void setHayCamino(boolean hayCamino) {
		this.hayCamino = hayCamino;
	}
	public boolean isEncontre() {
		return encontre;
	}
	public void setEncontre(boolean encontre) {
		this.encontre = encontre;
	}
}
