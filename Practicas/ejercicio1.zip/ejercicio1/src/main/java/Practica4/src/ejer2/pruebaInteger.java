package ejer2;

public class pruebaInteger {
	
	public static void main(String[]args) {
		
		Object objeto = new Object(6);
		
		Integer dato = (Integer)objeto;
		
		System.out.println(objeto);
	}
}
