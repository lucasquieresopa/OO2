package practica.OO2.ejercicio1;

public class TweetOriginal extends Tweet{

	public TweetOriginal(String texto) {
		super(texto);
	}
}
