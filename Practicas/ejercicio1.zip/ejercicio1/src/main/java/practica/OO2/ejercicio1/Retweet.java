package practica.OO2.ejercicio1;

public class Retweet extends Tweet{

	public Retweet(String texto) {
		super(texto);
	}
	
	public 
}
