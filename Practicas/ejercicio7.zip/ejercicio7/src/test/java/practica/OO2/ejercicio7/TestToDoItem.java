package practica.OO2.ejercicio7;

import java.util.Scanner;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TestToDoItem {

	private ToDoItem tdi;
	private Scanner in; 
	
	@BeforeEach
	public void setUp() {
		this.tdi = new ToDoItem("juan");
		this.in = new Scanner(System.in);
	}
	
	@Test
	public void testEstadoPending() {
		this.tdi.finish();
		this.tdi.togglePause();
		this.tdi.addComment(this.in.nextLine());
		this.tdi.workedTime();
	}
}
