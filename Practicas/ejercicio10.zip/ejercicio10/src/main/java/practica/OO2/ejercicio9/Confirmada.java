package practica.OO2.ejercicio9;

public class Confirmada extends Etapa{

	public void aprobarEtapa(Proyecto pr) {
		System.out.println("El proyecto ya se encuentra aprobado");
	}
	
	public void modificarMargenDeGanancia(Proyecto pr, double nuevoMargen) {
		
	}
}
